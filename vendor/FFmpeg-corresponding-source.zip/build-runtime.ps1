[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$W64DevkitDirectory,
    [Parameter(Mandatory=$true)][string]$NasmDirectory,
    [string]$GitBash = 'C:\Program Files\Git\bin\bash.exe',
    [string]$Python = 'python',
    [ValidateRange(1,32)][int]$Jobs = 8
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Push-Location -LiteralPath $PSScriptRoot
$yuiOriginalPath = $env:PATH
try {
    $yuiCompilerBin = Join-Path ([IO.Path]::GetFullPath($W64DevkitDirectory)) 'bin'
    $yuiNasmBin = [IO.Path]::GetFullPath($NasmDirectory)
    $yuiBashExe = [IO.Path]::GetFullPath($GitBash)
    foreach ($yuiRequired in @((Join-Path $yuiCompilerBin 'gcc.exe'), (Join-Path $yuiCompilerBin 'make.exe'), (Join-Path $yuiNasmBin 'nasm.exe'), $yuiBashExe)) {
        if (-not (Test-Path -LiteralPath $yuiRequired -PathType Leaf)) { throw ('Missing build tool: ' + [IO.Path]::GetFileName($yuiRequired)) }
    }
    $yuiManifest = Get-Content -LiteralPath 'BUILD.json' -Raw | ConvertFrom-Json
    foreach ($yuiSource in $yuiManifest.source_archives) {
        $yuiSourcePath = Join-Path $PSScriptRoot ('archives\' + $yuiSource.file)
        if ((Get-FileHash -LiteralPath $yuiSourcePath -Algorithm SHA256).Hash -ne $yuiSource.sha256) { throw ('Source checksum failed: ' + $yuiSource.file) }
    }
    & $Python 'extract-sources.py'
    if ($LASTEXITCODE -ne 0) { throw 'Could not extract source archives.' }
    $yuiGitTools = Join-Path (Split-Path -Parent (Split-Path -Parent $yuiBashExe)) 'usr\bin'
    $env:PATH = $yuiGitTools + ';' + $yuiCompilerBin + ';' + $yuiNasmBin + ';' + $yuiOriginalPath
    $env:YUI_RUNTIME_ROOT = $PSScriptRoot.Replace('\','/')
    $env:YUI_PYTHON = (& $Python -c 'import sys; print(sys.executable)').Trim().Replace('\','/')
    $env:YUI_SH = (Join-Path $yuiCompilerBin 'sh.exe').Replace('\','/')
    $env:YUI_BASH = $yuiBashExe.Replace('\','/')
    $env:YUI_JOBS = [string]$Jobs
    & (Join-Path $yuiCompilerBin 'sh.exe') './build-runtime.sh'
    if ($LASTEXITCODE -ne 0) { throw 'Runtime build failed.' }
    Get-FileHash -LiteralPath 'result\ffmpeg.exe' -Algorithm SHA256
}
finally {
    $env:PATH = $yuiOriginalPath
    Pop-Location
}
