#!/bin/sh
# Build only inside this extracted source package. Requires w64devkit, NASM,
# Python with Meson 1.10.0, and these unmodified upstream source directories.
set -eu
YUI_ROOT=${YUI_RUNTIME_ROOT:-$(pwd)}
YUI_PREFIX="$YUI_ROOT/prefix"
YUI_JOBS=${YUI_JOBS:-8}
mkdir -p "$YUI_PREFIX"
export PKG_CONFIG_PATH="$YUI_PREFIX/lib/pkgconfig"
export CC=gcc CXX=g++ AR=ar

cd "$YUI_ROOT/sources/zlib-1.3.2"
make -f win32/Makefile.gcc -j"$YUI_JOBS" libz.a
mkdir -p "$YUI_PREFIX/include" "$YUI_PREFIX/lib"
cp zlib.h zconf.h "$YUI_PREFIX/include/"
cp libz.a "$YUI_PREFIX/lib/"

cd "$YUI_ROOT/sources/x264-c24e06c2e184345ceb33eb20a15d1024d9fd3497"
"$YUI_SH" ./configure --prefix=../../prefix --host=x86_64-w64-mingw32 --enable-static --disable-cli --disable-opencl --disable-lavf --disable-swscale --disable-ffms --disable-gpac
make -j"$YUI_JOBS"
make install-lib-static

cd "$YUI_ROOT/sources/libvpx-1.17.0"
# Accept the compatible BusyBox diff supplied by w64devkit. This is the only
# upstream source change; the matching patch is included with the source.
"$YUI_PYTHON" -c 'from pathlib import Path; p=Path("configure"); s=p.read_text(); p.write_text(s.replace("if ! diff --version >/dev/null; then", "if ! command -v diff >/dev/null; then"), newline="\n")'
"$YUI_SH" ./configure --prefix=../../prefix --target=x86_64-win64-gcc --enable-static --disable-shared --disable-examples --disable-tools --disable-docs --disable-unit-tests
make -j"$YUI_JOBS"
make install

cd "$YUI_ROOT"
"$YUI_PYTHON" -m mesonbuild.mesonmain setup dav1d-build sources/dav1d-1.5.4 --prefix="$YUI_PREFIX" --libdir=lib --buildtype=release --default-library=static -Denable_tools=false -Denable_tests=false "-Dc_args=-ffile-prefix-map=$YUI_ROOT=."
"$YUI_PYTHON" -m mesonbuild.mesonmain compile -C dav1d-build -j "$YUI_JOBS"
"$YUI_PYTHON" -m mesonbuild.mesonmain install -C dav1d-build

cd "$YUI_ROOT/sources/ffmpeg-9.0.2"
"$YUI_SH" ./configure --prefix=../../ffmpeg-install --extra-version=yui-1 --target-os=mingw32 --arch=x86_64 --cc=gcc --cxx=g++ --ar=ar --ranlib=ranlib --nm=nm --pkg-config-flags=--static --extra-cflags=-I../../prefix/include --extra-ldflags=-L../../prefix/lib --extra-libs=-static --enable-gpl --enable-version3 --enable-static --disable-shared --disable-autodetect --enable-zlib --enable-libx264 --enable-libvpx --enable-libdav1d --enable-w32threads --disable-network --disable-protocols --enable-protocol=file,pipe --disable-indevs --enable-indev=lavfi --disable-outdevs --disable-ffplay --disable-ffprobe --disable-doc --disable-debug
make -j"$YUI_JOBS" V=1 ffmpeg.exe
strip ffmpeg.exe
mkdir -p "$YUI_ROOT/result"
cp ffmpeg.exe "$YUI_ROOT/result/ffmpeg.exe"
echo 'Yui offline FFmpeg runtime build complete.'
