"""Verify and extract the corresponding upstream source archives."""
from pathlib import Path
import hashlib
import json
import tarfile
import mesonbuild.coredata

ROOT = Path(__file__).resolve().parent
assert mesonbuild.coredata.version == '1.10.0', 'Install Meson 1.10.0 in the build Python environment.'
manifest = json.loads((ROOT / 'BUILD.json').read_text(encoding='utf-8'))
for item in manifest['source_archives']:
    archive = ROOT / 'archives' / item['file']
    assert archive.parent == ROOT / 'archives' and archive.name == item['file']
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == item['sha256'], item['file']
    with tarfile.open(archive) as package:
        package.extractall(ROOT / 'sources', filter='data')
print('Verified and extracted all corresponding source archives.')
