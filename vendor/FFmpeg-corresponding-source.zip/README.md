# FFmpeg 9.0.2, Yui offline build (yui-1)

This package contains complete corresponding source for the FFmpeg executable
bundled in Yui Gif Converter 1.4.1. `BUILD.json` identifies the exact binary,
original source archives, checksums, configuration, patch and build tools.

The FFmpeg source and all enabled external libraries are in `archives/`:
FFmpeg 9.0.2, x264 at the recorded commit, libvpx 1.17.0, dav1d 1.5.4 and zlib
1.3.2. Original copyrights/licenses remain inside those archives; relevant
binary redistribution notices are also in `licenses/`. No other optional
external libraries are enabled. Standard compiler and Windows runtime tools
are not included; their versions and download references are recorded.

One compatibility change is applied to libvpx's configure script so its diff
availability check accepts BusyBox. The patch and the script that applies it
are included. No other upstream source file was changed.

To rebuild on Windows x64:
1. Extract this ZIP to a fresh local folder, preferably without spaces.
2. Obtain/extract the w64devkit 2.10.0 x64 and NASM 3.02 Windows tool archives
   referenced in BUILD.json. Verify their SHA-256 values before using them.
3. Install Git for Windows with Bash and 64-bit Python 3.14.8. Create a build
   Python environment and install Meson 1.10.0:
   `python -m venv .build-python`
   `.build-python\Scripts\python.exe -m pip install meson==1.10.0`
4. Run PowerShell from this folder:

```powershell
.\build-runtime.ps1 -W64DevkitDirectory 'C:\Tools\w64devkit' -NasmDirectory 'C:\Tools\nasm-3.02' -Python '.build-python\Scripts\python.exe'
```

The script verifies and safely extracts the original sources, builds the four
external libraries and FFmpeg, and writes `result/ffmpeg.exe`. It does not
download anything or install runtime components into Windows. Compilation
uses only the checked local source files. The released executable is not
claimed to be bit-for-bit reproducible across machines or build dates. When
building a modified Yui app, review the new executable and update its pinned
SHA-256 in yui/runtime.py; see the app's docs/DEVELOPMENT.md.

FFmpeg is a separate GPLv3 program. This ZIP supplies its corresponding
source alongside the executable in the full public download. Preserve the
source and applicable notices when redistributing the combined download.
